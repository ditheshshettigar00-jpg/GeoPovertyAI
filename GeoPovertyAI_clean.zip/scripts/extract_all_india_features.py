"""
extract_all_india_features.py
------------------------------
Master script: fetches district boundaries and extracts GEE satellite
features for ALL 34 Indian states. Saves progress after each state so
it can be safely interrupted and resumed.

Outputs:
  data/raw/districts_<State>.json       -- boundary + centroid per state
  data/processed/real_geospatial_features.csv  -- merged features for all districts
"""
import json, os, sys, time
from concurrent.futures import ThreadPoolExecutor
import pandas as pd

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from geospatial.gee_config import initialize_ee, GAUL_LEVEL2, VIIRS_MONTHLY, VIIRS_BAND, SENTINEL2_SR
from geospatial.ghsl_features import builtup_pct_for, population_density_for
from config import RAW_DIR, PROCESSED_DIR, GEE_START_DATE, GEE_END_DATE

STATES = [
    "Andaman and Nicobar","Andhra Pradesh","Arunachal Pradesh","Assam",
    "Bihar","Chandigarh","Chhattisgarh","Dadra and Nagar Haveli",
    "Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh",
    "Jharkhand","Karnataka","Kerala","Lakshadweep","Madhya Pradesh",
    "Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Orissa",
    "Puducherry","Punjab","Rajasthan","Sikkim","Tamil Nadu","Tripura",
    "Uttar Pradesh","Uttarakhand","West Bengal"
]

START_DATE = GEE_START_DATE   # matches NFHS-5 fieldwork (2019-2021); set in config.py
END_DATE   = GEE_END_DATE
OUT_CSV    = os.path.join(PROCESSED_DIR, "real_geospatial_features.csv")
PROGRESS_FILE = "data/raw/gee_extraction_progress.json"

# Speed settings. Earth Engine calls spend most of their time waiting on the network, so several
# districts can be processed at once. If you see "Too many concurrent" errors, lower MAX_WORKERS.
MAX_WORKERS = 6
# District-mean NDVI is practically identical at 30 m and about 9x cheaper than at 10 m.
# Mention this in the report ("NDVI aggregated at 30 m").
NDVI_SCALE_M = 30

def mask_s2_clouds(image, ee):
    scl = image.select("SCL")
    good = scl.eq(4).Or(scl.eq(5)).Or(scl.eq(6)).Or(scl.eq(7))
    return image.updateMask(good).divide(10000)

def reduce_mean(ee, image, geometry, band, scale):
    result = image.select(band).reduceRegion(
        reducer=ee.Reducer.mean(), geometry=geometry,
        scale=scale, maxPixels=1e9, bestEffort=True, tileScale=4
    ).getInfo()
    return result.get(band)

def fetch_boundaries(ee, state):
    fc = (ee.FeatureCollection(GAUL_LEVEL2)
          .filter(ee.Filter.eq("ADM0_NAME","India"))
          .filter(ee.Filter.eq("ADM1_NAME", state)))
    count = fc.size().getInfo()
    if count == 0:
        print(f"  WARNING: No districts found for {state}")
        return []
    features = fc.getInfo()["features"]
    rows = []
    for i, feat in enumerate(features, 1):
        props = feat["properties"]
        geom  = feat["geometry"]
        centroid = ee.Geometry(geom).centroid(maxError=1).coordinates().getInfo()
        rows.append({"area_id": i, "area_name": props.get("ADM2_NAME", f"District_{i}"),
                     "state_name": state, "latitude": centroid[1], "longitude": centroid[0],
                     "geometry": geom})
    return rows

def extract_features(ee, district):
    geom = ee.Geometry(district["geometry"])
    row = {k: district[k] for k in ["area_id","area_name","state_name","latitude","longitude"]}
    row["data_mode"] = "real"
    # VIIRS nighttime lights
    try:
        viirs = ee.ImageCollection(VIIRS_MONTHLY).filterDate(START_DATE, END_DATE).select(VIIRS_BAND).mean()
        row["nightlight_mean"] = reduce_mean(ee, viirs, geom, VIIRS_BAND, 500)
    except Exception as ex:
        row["nightlight_mean"] = None
        print(f"    nightlight error: {ex}")
    # Sentinel-2 NDVI
    try:
        col = (ee.ImageCollection(SENTINEL2_SR).filterBounds(geom)
               .filterDate(START_DATE, END_DATE)
               .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 20))
               .map(lambda img: mask_s2_clouds(img, ee)))
        n = col.size().getInfo()
        if n > 0:
            ndvi = col.median().normalizedDifference(["B8","B4"]).rename("NDVI")
            row["ndvi_mean"] = reduce_mean(ee, ndvi, geom, "NDVI", NDVI_SCALE_M)
            row["s2_image_count"] = n
        else:
            row["ndvi_mean"] = None; row["s2_image_count"] = 0   # stays missing, never filled with a median here
    except Exception as ex:
        # An error is NOT the same as "no images": leave the count missing so it is not confused with a real zero.
        row["ndvi_mean"] = None; row["s2_image_count"] = None
        print(f"    NDVI error for {district['area_name']}: {ex}")
    # GHSL built-up share (true %, survey-period epoch) and population density (people per km2)
    try:
        row["builtup_pct"] = builtup_pct_for(ee, geom)
    except Exception as ex:
        row["builtup_pct"] = None
        print(f"    builtup error: {ex}")
    try:
        row["population_density"] = population_density_for(ee, geom)
    except Exception as ex:
        row["population_density"] = None
        print(f"    population error: {ex}")
    return row

def extract_with_retry(ee, district, attempts=3):
    """Retries transient Earth Engine failures with a short back-off."""
    for k in range(attempts):
        try:
            return extract_features(ee, district)
        except Exception as ex:
            if k == attempts - 1:
                print(f"  [{district['area_name']}] ERROR after {attempts} tries: {ex}")
                return None
            time.sleep(2 ** (k + 1))


def main():
    ee = initialize_ee()
    os.makedirs(RAW_DIR, exist_ok=True)
    os.makedirs(PROCESSED_DIR, exist_ok=True)

    # Load progress
    done_states = set()
    all_rows = []
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE) as f:
            done_states = set(json.load(f))
        print(f"Resuming -- already done: {done_states}")
    if os.path.exists(OUT_CSV):
        all_rows = pd.read_csv(OUT_CSV).to_dict("records")
        print(f"Loaded {len(all_rows)} existing rows from {OUT_CSV}")

    for state in STATES:
        if state in done_states:
            print(f"Skipping {state} (already done)")
            continue

        print(f"\n{'='*50}")
        print(f"Processing state: {state}")
        print(f"{'='*50}")

        # Fetch boundaries
        boundary_file = os.path.join(RAW_DIR, f"districts_{state.replace(' ','_')}.json")
        if os.path.exists(boundary_file):
            with open(boundary_file) as f:
                districts = json.load(f)
            print(f"  Loaded {len(districts)} districts from cache")
        else:
            districts = fetch_boundaries(ee, state)
            if not districts:
                continue
            with open(boundary_file, "w") as f:
                json.dump(districts, f)
            print(f"  Saved {len(districts)} district boundaries")

        # Extract features (several districts at a time; results keep the original order)
        state_rows = []
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
            results = pool.map(lambda d: extract_with_retry(ee, d), districts)
            for d, row in zip(districts, results):
                if row is None:
                    continue
                state_rows.append(row)
                nl = row.get("nightlight_mean")
                print(f"  [{d['area_name']}] " + (f"nightlight={nl:.3f}" if nl else "done"), flush=True)

        all_rows.extend(state_rows)

        # Save progress after each state
        pd.DataFrame(all_rows).to_csv(OUT_CSV, index=False)
        done_states.add(state)
        with open(PROGRESS_FILE, "w") as f:
            json.dump(list(done_states), f)
        print(f"  Saved progress: {len(all_rows)} total districts so far")

    print(f"\nDONE! Total districts extracted: {len(all_rows)}")
    print(f"Output saved to: {OUT_CSV}")

if __name__ == "__main__":
    main()

"""
test_pipeline.py
-------------------
Test suite covering: dataset generation, feature fusion, geography-aware
validation, model training utilities, and the Flask API. Uses the demo
(synthetic) pipeline throughout, since it requires no external network
access (GEE/OSM) and runs anywhere.

Run with:
    pytest tests/ -v
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.generate_demo_data import generate_demo_dataset
from preprocessing.feature_fusion import (
    remove_duplicates, impute_missing, clip_outliers_iqr, fuse_features,
)
from training.geo_validation import grouped_train_test_split, get_group_kfold
from training.train_models import get_feature_columns


# ---------------------------------------------------------------------------
# Dataset generation
# ---------------------------------------------------------------------------

def test_demo_dataset_shape_and_no_missing_values():
    df = generate_demo_dataset(n_areas=30, seed=1)
    assert len(df) == 30
    assert "deprivation_score" in df.columns
    assert df["deprivation_score"].between(0, 1).all()
    assert df.isna().sum().sum() == 0


def test_demo_dataset_reproducible_with_same_seed():
    df1 = generate_demo_dataset(n_areas=10, seed=5)
    df2 = generate_demo_dataset(n_areas=10, seed=5)
    pd.testing.assert_frame_equal(df1, df2)


# ---------------------------------------------------------------------------
# Feature fusion building blocks
# ---------------------------------------------------------------------------

def test_remove_duplicates_keeps_first():
    df = pd.DataFrame({"area_id": [1, 1, 2], "val": [10, 20, 30]})
    result = remove_duplicates(df, "test")
    assert len(result) == 2
    assert result[result["area_id"] == 1]["val"].iloc[0] == 10


def test_impute_missing_fills_with_median():
    df = pd.DataFrame({"x": [1.0, 2.0, np.nan, 4.0]})
    result = impute_missing(df, ["x"])
    assert result["x"].isna().sum() == 0
    assert result.loc[2, "x"] == pytest.approx(df["x"].median())


def test_clip_outliers_bounds_extreme_values():
    df = pd.DataFrame({"x": [1, 2, 3, 4, 5, 1000]})
    result = clip_outliers_iqr(df, ["x"], iqr_multiplier=1.5)
    assert result["x"].max() < 1000
    # non-outlier values should be unaffected
    assert result["x"].iloc[0] == 1


def test_fuse_features_merges_and_reports_mismatched_ids(tmp_path):
    gt = pd.DataFrame({"area_id": [1, 2, 3], "deprivation_score": [0.2, 0.5, 0.8]})
    geo = pd.DataFrame({"area_id": [1, 2, 3], "nightlight_mean": [1.0, 2.0, 3.0]})
    acc = pd.DataFrame({"area_id": [1, 2], "road_density_km_per_sqkm": [0.5, 0.6]})  # id 3 missing on purpose
    vgg = pd.DataFrame({"area_id": [1, 2, 3], "vgg_feat_1": [0.1, 0.2, 0.3]})

    gt.to_csv(tmp_path / "gt.csv", index=False)
    geo.to_csv(tmp_path / "geo.csv", index=False)
    acc.to_csv(tmp_path / "acc.csv", index=False)
    vgg.to_csv(tmp_path / "vgg.csv", index=False)

    result = fuse_features(str(tmp_path / "gt.csv"), str(tmp_path / "geo.csv"),
                            str(tmp_path / "acc.csv"), str(tmp_path / "vgg.csv"))

    assert len(result) == 2  # only area_id 1 and 2 are present in ALL sources
    assert 3 not in result["area_id"].values
    assert result.isna().sum().sum() == 0


# ---------------------------------------------------------------------------
# Geography-aware validation
# ---------------------------------------------------------------------------

def test_grouped_split_holds_out_entire_states():
    df = generate_demo_dataset(n_areas=60, seed=2)
    X = df.drop(columns=["deprivation_score"])
    y = df["deprivation_score"]
    groups = df["state_name"]

    X_train, X_test, y_train, y_test, groups_train, groups_test = grouped_train_test_split(
        X, y, groups, test_size=0.3, random_state=1
    )

    train_states = set(groups_train)
    test_states = set(groups_test)
    assert train_states.isdisjoint(test_states), "A state leaked into both train and test!"
    assert len(X_train) + len(X_test) == len(df)


def test_group_kfold_rejects_too_few_groups():
    with pytest.raises(ValueError):
        get_group_kfold(n_groups_available=1, max_splits=5)


def test_group_kfold_reduces_splits_when_few_groups_available():
    cv = get_group_kfold(n_groups_available=2, max_splits=5)
    assert cv.get_n_splits() == 2


# ---------------------------------------------------------------------------
# Feature column detection
# ---------------------------------------------------------------------------

def test_get_feature_columns_excludes_identifiers_and_target():
    df = generate_demo_dataset(n_areas=5, seed=3)
    cols = get_feature_columns(df)
    assert "deprivation_score" not in cols
    assert "area_id" not in cols
    assert "state_name" not in cols
    assert "nightlight_mean" in cols
    assert "vgg_feat_1" in cols


# ---------------------------------------------------------------------------
# Flask API (requires database/geopoverty.db + models/ to already be populated
# by running Modules 1, 5, and 6's scripts first -- these tests are skipped
# gracefully if that setup hasn't been run yet, rather than failing confusingly)
# ---------------------------------------------------------------------------

# The `client` fixture (logged in as a RESEARCHER) lives in tests/conftest.py.


def test_home_page_loads(client):
    r = client.get("/")
    assert r.status_code == 200


def test_api_areas_returns_list(client):
    r = client.get("/api/areas")
    assert r.status_code == 200
    data = r.get_json()
    assert isinstance(data, list)
    assert len(data) > 0
    assert "area_id" in data[0]


def test_api_predict_valid_area(client):
    areas = client.get("/api/areas").get_json()
    area_id = areas[0]["area_id"]
    r = client.get(f"/api/predict/{area_id}")
    assert r.status_code == 200
    data = r.get_json()
    assert "predicted_score" in data
    assert data["predicted_category"] in ("Low", "Medium", "High")


def test_api_predict_invalid_area_returns_404(client):
    r = client.get("/api/predict/999999")
    assert r.status_code == 404


def test_api_explain_returns_shap_and_flags_gradcam(client):
    areas = client.get("/api/areas").get_json()
    area_id = areas[0]["area_id"]
    r = client.get(f"/api/explain/{area_id}")
    assert r.status_code == 200
    data = r.get_json()
    assert "shap_explanation" in data
    assert "top_contributions" in data["shap_explanation"]
    assert "gradcam_available" in data


def test_api_scenario_missing_body_returns_400(client):
    r = client.post("/api/scenario", json={})
    assert r.status_code == 400


def test_api_scenario_valid_request(client):
    areas = client.get("/api/areas").get_json()
    area_id = areas[0]["area_id"]
    r = client.post("/api/scenario", json={"area_id": area_id, "modified_features": {"builtup_pct": 10}})
    assert r.status_code == 200
    data = r.get_json()
    assert "original_score" in data
    assert "scenario_score" in data
    assert "not a causal simulation" in data["note"]


def test_api_scenario_unknown_feature_returns_400(client):
    areas = client.get("/api/areas").get_json()
    area_id = areas[0]["area_id"]
    r = client.post("/api/scenario", json={"area_id": area_id, "modified_features": {"totally_fake_feature": 1}})
    assert r.status_code == 400


def test_api_model_performance_returns_metrics(client):
    r = client.get("/api/model-performance")
    assert r.status_code == 200
    data = r.get_json()
    assert isinstance(data, list)
    if len(data) > 0:
        assert "mae" in data[0] and "rmse" in data[0] and "r2" in data[0]


def test_api_predict_live_custom_features(client):
    payload = {
        "nightlight_mean": 4.5,
        "ndvi_mean": 0.40,
        "builtup_pct": 250.0,
        "population_density": 500.0
    }
    r = client.post("/api/predict-live", json=payload)
    assert r.status_code == 200
    data = r.get_json()
    assert "predicted_score" in data
    assert data["predicted_category"] in ("Low", "Medium", "High")
    assert "contributions" in data
    
    try:
        import shap
        has_shap = True
    except ImportError:
        has_shap = False
        
    if has_shap:
        assert len(data["contributions"]) > 0
        
    assert "interpretation" in data


def test_auth_register_and_login(client):
    # Register
    import time
    unique_email = f"testuser_{int(time.time())}@example.com"
    r_reg = client.post("/api/auth/register", json={
        "name": "Test User",
        "email": unique_email,
        "password": "password123"
    })
    assert r_reg.status_code == 201
    
    # Login
    r_login = client.post("/api/auth/login", json={
        "email": unique_email,
        "password": "password123"
    })
    assert r_login.status_code == 200
    assert "user" in r_login.get_json()
    
    # Profile (should be successful since logged in)
    r_prof = client.get("/api/auth/profile")
    assert r_prof.status_code == 200
    
    # Logout
    r_out = client.post("/api/auth/logout")
    assert r_out.status_code == 200
    
    # Profile should fail now
    r_prof_fail = client.get("/api/auth/profile")
    assert r_prof_fail.status_code == 401


def test_admin_route_protection(anon_client):
    client = anon_client
    # Unauthenticated access to HTML route
    r = client.get("/admin")
    assert r.status_code == 302 # Redirect to login
    
    # Unauthenticated access to API route
    r_api = client.get("/api/admin/dashboard-stats")
    assert r_api.status_code == 401


def test_report_generation_protection(anon_client):
    client = anon_client
    # Need researcher/admin role
    areas = client.get("/api/areas").get_json()
    if areas:
        area_id = areas[0]["area_id"]
        r = client.get(f"/api/reports/district/{area_id}")
        assert r.status_code == 401


# ---------------------------------------------------------------------------
# Phase 1 Data Integrity & District Matching Tests
# ---------------------------------------------------------------------------

def test_final_table_data_ranges_and_integrity():
    from config import PROCESSED_DIR
    path = os.path.join(PROCESSED_DIR, "final_training_table.csv")
    if not os.path.exists(path):
        pytest.skip("final_training_table.csv not found")
    df = pd.read_csv(path)
    
    # 1. No builtup_pct > 100
    if "builtup_pct" in df.columns:
        b = df["builtup_pct"].dropna()
        assert (b <= 100.0).all(), "builtup_pct values exceed 100%"
        assert (b >= 0.0).all(), "builtup_pct values below 0%"

    # 2. Population density valid rangepytest tests/test_pipeline.py -k final_table -v
        assert (df["population_density"].dropna() >= 0.0).all()

    # 3. No constant columns across real districts
    num_cols = ["nightlight_mean", "ndvi_mean", "builtup_pct", "population_density", "deprivation_score"]
    for col in num_cols:
        if col in df.columns:
            assert df[col].nunique() > 1, f"Column {col} is a constant placeholder"


def test_district_matching_stays_inside_state():
    from preprocessing.name_keys import clean_key, state_key
    from scripts.build_real_training_table import match_districts

    geo = pd.DataFrame({
        "area_name": ["Dharwad", "Belagavi"],
        "state_name": ["Karnataka", "Karnataka"],
        "latitude": [15.4, 15.8],
        "longitude": [75.0, 74.5],
        "nightlight_mean": [2.1, 3.2],
        "ndvi_mean": [0.35, 0.42],
        "builtup_pct": [12.0, 18.0],
        "population_density": [300.0, 400.0]
    })

    # Ground truth with one exact match in Karnataka, and same name in DIFFERENT state
    gt = pd.DataFrame({
        "area_name": ["Dharwad", "Belagavi"],
        "state_name": ["Karnataka", "Maharashtra"],  # Belagavi placed under Maharashtra
        "deprivation_score": [0.45, 0.50]
    })

    report, used, _ = match_districts(geo, gt, aliases={})
    
    # Dharwad should match exact
    dharwad_match = report[report["gaul_district"] == "Dharwad"].iloc[0]
    assert dharwad_match["method"] == "exact"
    assert dharwad_match["nfhs_state"] == "Karnataka"

    # Belagavi in Karnataka must NOT match Belagavi in Maharashtra (stays inside state)
    belagavi_match = report[report["gaul_district"] == "Belagavi"].iloc[0]
    assert belagavi_match["method"] == "UNMATCHED"


def test_stored_scores_equal_loso_predictions(client):
    from config import DB_PATH, MODELS_DIR
    loso_path = os.path.join(MODELS_DIR, "loso_predictions.csv")
    if not os.path.exists(loso_path) or not os.path.exists(DB_PATH):
        pytest.skip("loso_predictions.csv or database not available")

    loso_df = pd.read_csv(loso_path)
    assert len(loso_df) > 0

    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    # Fetch latest prediction per area
    cur.execute("""
        SELECT p.area_id, p.predicted_score, p.predicted_low, p.predicted_high
        FROM predictions p
        WHERE p.prediction_id = (
            SELECT MAX(p2.prediction_id) FROM predictions p2 WHERE p2.area_id = p.area_id
        )
    """)
    db_rows = {row[0]: (row[1], row[2], row[3]) for row in cur.fetchall()}
    conn.close()

    # Verify stored scores equal loso_predictions.csv values
    matched_count = 0
    for _, r in loso_df.iterrows():
        aid = int(r["area_id"])
        if aid in db_rows:
            pred_score, pred_low, pred_high = db_rows[aid]
            assert np.isclose(pred_score, r["y_pred_out_of_state"], atol=1e-4), (
                f"Score mismatch for area_id {aid}: db={pred_score}, loso={r['y_pred_out_of_state']}"
            )
            if pred_low is not None and pd.notna(r["low_80"]):
                assert np.isclose(pred_low, r["low_80"], atol=1e-4)
            if pred_high is not None and pd.notna(r["high_80"]):
                assert np.isclose(pred_high, r["high_80"], atol=1e-4)
            matched_count += 1

    assert matched_count == len(loso_df)

    # Also verify API endpoints return predicted_low and predicted_high
    first_aid = int(loso_df.iloc[0]["area_id"])
    r_pred = client.get(f"/api/predict/{first_aid}")
    assert r_pred.status_code == 200
    d_pred = r_pred.get_json()
    assert "predicted_low" in d_pred
    assert "predicted_high" in d_pred
    assert np.isclose(d_pred["predicted_score"], loso_df.iloc[0]["y_pred_out_of_state"], atol=1e-4)

    r_areas = client.get("/api/areas")
    assert r_areas.status_code == 200
    d_areas = r_areas.get_json()
    assert len(d_areas) > 0
    assert "predicted_low" in d_areas[0]
    assert "predicted_high" in d_areas[0]

    r_map = client.get("/api/map")
    assert r_map.status_code == 200
    d_map = r_map.get_json()
    assert len(d_map) > 0
    assert "predicted_low" in d_map[0]
    assert "predicted_high" in d_map[0]

